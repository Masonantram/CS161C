// Created by mason on 3/15/2024.

#ifndef LAB7_MWA_HEADER_HPP
#define LAB7_MWA_HEADER_HPP

#include "Player Class.hpp"

int getInteger (int min, int max);
Player* createPlayer();
void displayArrays (Player** array, const int size);

#endif //LAB7_MWA_HEADER_HPP
