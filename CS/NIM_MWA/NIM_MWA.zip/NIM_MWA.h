//
// Created by mason on 11/20/2023.
//

#ifndef NIM_MWA_NIM_MWA_H
void showInstructions() ;
int showBoard(int numSticks);
int getMove(int numSticks);
bool playAgain();
#define NIM_MWA_NIM_MWA_H

#endif //NIM_MWA_NIM_MWA_H
