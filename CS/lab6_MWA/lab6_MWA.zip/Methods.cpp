// Created by mason on 3/7/2024.

#include "Classes.hpp"

//Constructors
Student::Student() { this->name = " "; this->age = 0;}
Student::Student (std::string name, int age) { this -> name = name; this -> age = age;}
